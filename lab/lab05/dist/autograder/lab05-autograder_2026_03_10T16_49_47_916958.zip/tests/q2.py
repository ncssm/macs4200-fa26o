OK_FORMAT = True

test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': ">>> plaintext[0:10] != 'We choose '\nTrue",
                                       'failure_message': 'You loaded, but did not clean the plaintext',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 0},
                                   {   'code': ">>> plaintext[-10:]\n'EOTHERSTOO'",
                                       'failure_message': 'You did not load and clean the plaintext',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': 'You sucessfully loaded and cleaned the plaintext'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
