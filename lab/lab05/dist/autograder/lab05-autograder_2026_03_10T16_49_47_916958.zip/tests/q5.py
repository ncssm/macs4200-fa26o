OK_FORMAT = True

test = {   'name': 'q5',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> from helpers import ioc\n>>> ioc(plaintext) > 0.07 and ioc(vigenere(plaintext, keyword)) < 0.045\nTrue',
                                       'failure_message': 'You did not pick a "good enough" keyword that disguises letter frequencies',
                                       'hidden': False,
                                       'locked': False,
                                       'points': 1,
                                       'success_message': 'You picked a good keyword that disguised letter frequencies'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
