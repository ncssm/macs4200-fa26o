OK_FORMAT = True

test = {   'name': 'q6',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> len(bucket_01)\n145', 'hidden': False, 'locked': False},
                                   {'code': ">>> bucket_01[15]\n'M'", 'hidden': False, 'locked': False},
                                   {'code': ">>> bucket_01[75]\n'E'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
