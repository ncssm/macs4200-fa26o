OK_FORMAT = True

test = {   'name': 'q8',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> clear_bit(255, bit_index=6)\n223', 'hidden': False, 'locked': False},
                                   {'code': '>>> clear_bit(255, bit_index=4)\n247', 'hidden': False, 'locked': False},
                                   {'code': '>>> clear_bit(255, bit_index=3)\n251', 'hidden': False, 'locked': False},
                                   {'code': '>>> clear_bit(255, bit_index=1)\n254', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
