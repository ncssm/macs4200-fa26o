OK_FORMAT = True

test = {   'name': 'q7',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> set_bit(2, bit_index=4)\n10', 'hidden': False, 'locked': False},
                                   {'code': '>>> set_bit(128, bit_index=6)\n160', 'hidden': False, 'locked': False},
                                   {'code': '>>> set_bit(128, bit_index=5)\n144', 'hidden': False, 'locked': False},
                                   {'code': '>>> set_bit(128, bit_index=3)\n132', 'hidden': False, 'locked': False},
                                   {'code': '>>> set_bit(128, bit_index=1)\n129', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
