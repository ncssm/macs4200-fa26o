OK_FORMAT = True

test = {   'name': 'q9',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> toggle_bit(18, bit_index=3)\n22', 'hidden': False, 'locked': False}, {'code': '>>> toggle_bit(18, bit_index=5)\n2', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
