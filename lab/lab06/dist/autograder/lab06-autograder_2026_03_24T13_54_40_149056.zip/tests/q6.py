OK_FORMAT = True

test = {   'name': 'q6',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> get_bit(161, bit_index=1)\n1', 'hidden': False, 'locked': False},
                                   {'code': '>>> get_bit(161, bit_index=2)\n0', 'hidden': False, 'locked': False},
                                   {'code': '>>> get_bit(161, bit_index=6)\n1', 'hidden': False, 'locked': False},
                                   {'code': '>>> get_bit(161, bit_index=8)\n1', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
