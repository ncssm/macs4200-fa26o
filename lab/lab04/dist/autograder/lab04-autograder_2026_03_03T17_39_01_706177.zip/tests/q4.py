OK_FORMAT = True

test = {   'name': 'q4',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> q4('ABCDEFG', 107)\n'C'", 'hidden': False, 'locked': False},
                                   {'code': ">>> q4('SECRETKEY', 1953)\n'S'", 'hidden': False, 'locked': False},
                                   {'code': ">>> q4('PLEASEDONTGUESS', 323423535234)\n'T'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
