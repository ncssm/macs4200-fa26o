OK_FORMAT = True

test = {   'name': 'q1',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> q1(names, grades)\nAlexis 2\nDee 3\nDaryl 2\nSebastian 3\nOra 1\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> q1([0, 1, 2], [3, 4, 5])\n0 3\n1 4\n2 5\n', 'hidden': False, 'locked': False},
                                   {'code': '>>> q1(range(0, 10), range(10, 20))\n0 10\n1 11\n2 12\n3 13\n4 14\n5 15\n6 16\n7 17\n8 18\n9 19\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
