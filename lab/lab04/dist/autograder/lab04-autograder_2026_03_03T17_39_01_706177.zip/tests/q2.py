OK_FORMAT = True

test = {   'name': 'q2',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> q2('secret', 'blaise')\ns b\ne l\nc a\nr i\ne s\nt e\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> q2('ncssm', 'smath')\nn s\nc m\ns a\ns t\nm h\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> q2('hello', 'world')\nh w\ne o\nl r\nl l\no d\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
