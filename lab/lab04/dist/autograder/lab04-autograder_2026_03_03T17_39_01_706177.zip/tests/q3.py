OK_FORMAT = True

test = {   'name': 'q3',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> q3('ABCDEFG', 'thisisalongermessage')\n'ABCDEFGABCDEFGABCDEF'", 'hidden': False, 'locked': False},
                                   {'code': ">>> q3('1234', 'wowthismessageisalsoprettylong')\n'123412341234123412341234123412'", 'hidden': False, 'locked': False},
                                   {   'code': ">>> q3('MATH', 'somehowthismessageisevenlongerthanbothoftheothermessages')\n'MATHMATHMATHMATHMATHMATHMATHMATHMATHMATHMATHMATHMATHMATH'",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
